#!/usr/bin/bash
                       # Bash Script to Analyze Network Traffic #
############################ Script Description ###########################################
# 1. Objective :
# This Script used to analyze network traffic using Wireshark and automate specific tasks
# with Bash script , generating a summary report.

# 2. Scope :
# 1.Capture network traffic using Wireshark.(in pcap file)
# 2.Take file path as input (From Terminal) Then Analyze the captured data which saved in file.
# 3.Extract relevant information like total packets, protocols, and top source/destination IP addresses.
# 4.Generate a summary report based on the analysis.

############################ Global Variables & Function decleration ###########################
# - Variables: 

# Input: Path to the Wireshark pcap file
pcap_file=$1 
# File used to save extracted src/dst IP Addresses
file_src="ip_packets.txt"

# - Functions:

# Function Check existance of pcap File
function file_existance () {

   if [[ -f ${pcap_file} ]]; then
        echo "Start Analyzing File.."    
     else 
        echo "File not exists"
        exit 1;
     fi
}
# Function to extract information from the pcap file
function analyze_traffic() {

     # Check existance of pcap file before start analyizing
     file_existance

     # Use tshark commands for packet analysis.   
     
      declare -i total_packets=`tshark -r ${pcap_file} | wc -l`

      declare -i http_packets=`tshark -r capture.pcap -Y "http" | wc -l`
      
      declare -i https_packets=`tshark -r ${pcap_file} -Y "tls" | wc -l`
  
    # Output analysis summary
     echo "----- Network Traffic Analysis Report -----"
     # Provide summary information based on analysis
     # Total packets, protocols (HTTP/HTTPS/TLS), top source, and destination IP addresses.
     echo "1. Total Packets: $total_packets"
   
     echo "2. Protocols:"
     echo "   - HTTP:      $http_packets  Packets"
     echo "   - HTTPS/TLS: $https_packets Packets"
     echo ""
     # Provide the top source IP addresses
     echo "3. Top 5 Source IP Addresses:"
        # Extract 5 top source ip addresses 
         tshark -r ${pcap_file} -T fields -e ip.src > ${file_src}
         awk '{ count[$1]++; } END { for (ip in count) { printf "%d :  %s\n", count[ip], ip; } }' ${file_src} | sort -r -n | head -n 5         
         
        
         echo ""
     # Provide the top destination IP addresses
     echo "4. Top 5 Destination IP Addresses:"
        # Extract 5 top destination ip addresses 
         tshark -r ${pcap_file} -T fields -e ip.dst > ${file_src}
         awk '{ count[$1]++; } END { for (ip in count) { printf "%d :  %s\n", count[ip], ip; } }' ${file_src} | sort -r -n | head -n 5         

     echo ""
     echo "----- End of Report -----"
}
############################ main Function #########################################################
function main () {

 # Run the analysis function
 analyze_traffic

}
############################ Calling main ##########################################################
 main




